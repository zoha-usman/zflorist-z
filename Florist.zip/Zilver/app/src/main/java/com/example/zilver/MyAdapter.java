package com.example.zilver;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class MyAdapter extends RecyclerView.Adapter<MyAdapter.ViewHolder>{

    Model[] mymodel;
    Context context;
    public MyAdapter(Model[] mymodel, Context context) {
        this.mymodel = mymodel;
        this.context = context;
    }


    @NonNull
    @Override
    public MyAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View view = layoutInflater.inflate(R.layout.item_view, parent, false);
        ViewHolder viewHolder = new ViewHolder(view);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull MyAdapter.ViewHolder holder, int position) {
        final Model mymodellist = mymodel[position];
        holder.fname.setText(mymodellist.getName());
        holder.fimg.setImageResource(mymodellist.getImg());

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(context,Detail_activity.class);
                intent.putExtra("jewimg",mymodellist.getImg());
                intent.putExtra("jewname",mymodellist.getName());
                intent.putExtra("jewdata",mymodellist.getData());
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(intent);
            }
        });
    }

    @Override
    public int getItemCount() {
        return mymodel.length;
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        ImageView fimg;
        TextView fname;
        TextView fdata;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            fimg = itemView.findViewById(R.id.imageview);
            fname = itemView.findViewById(R.id.textName);
            fdata = itemView.findViewById(R.id.textdate);
        }
    }
}