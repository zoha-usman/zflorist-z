package com.example.zilver;

public class Model {

    private String name;
    private String data;
    private Integer img;

    public Model(String name, String data, Integer img) {
        this.name =name;
        this.data = data;
        this.img = img;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }

    public Integer getImg() {
        return img;
    }

    public void setImg(Integer img) {
        this.img = img;
    }



}
