package com.example.zilver;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;



public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        RecyclerView recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        Model[] model = new Model[]{
                new Model(" Online Shop","Fresh Flowers for You",R.drawable.logoapp),
                new Model("Black Rose","Available at Rs:500",R.drawable.blackwhite),
                new Model("Pink Rose","Available at Rs:600",R.drawable.red1),
                new Model("White Rose","Available at Rs:300",R.drawable.white),
                new Model("Yellow rose","Available at Rs:400",R.drawable.yellow),
                new Model("Black Rose","Available at Rs:700",R.drawable.black),
                new Model("Red Rose","Available at Rs:1000",R.drawable.special),
                new Model("Red Rose","Available at Rs:1000",R.drawable.cakeandflower),
                new Model("Red Rose","Available at Rs:1000",R.drawable.cakeflower),
                new Model("Red Rose","Available at Rs:1000",R.drawable.cakeset),
                new Model("Black Rose","Available at Rs:",R.drawable.black),
        };

        MyAdapter myAdapter = new MyAdapter(model,MainActivity.this);
        recyclerView.setAdapter(myAdapter);
    }
}